// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("upload artifacts\n", stdout);
  return lionss_run_workload("upload-artifacts");
}
