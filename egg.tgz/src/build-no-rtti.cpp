// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("build no rtti\n", stdout);
  return lionss_run_workload("build-no-rtti");
}
