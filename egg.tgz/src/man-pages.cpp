// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("man pages\n", stdout);
  return lionss_run_workload("man-pages");
}
