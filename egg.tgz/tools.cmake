# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(man-pages src/man-pages.cpp)
set_property(TARGET man-pages PROPERTY CXX_STANDARD 11)
target_link_libraries(man-pages lionss pthread)

add_executable(google-benchmark src/google-benchmark.cpp)
set_property(TARGET google-benchmark PROPERTY CXX_STANDARD 11)
target_link_libraries(google-benchmark lionss pthread)

add_executable(symbol-visibility src/symbol-visibility.cpp)
set_property(TARGET symbol-visibility PROPERTY CXX_STANDARD 11)
target_link_libraries(symbol-visibility lionss pthread)

add_executable(build-no-rtti src/build-no-rtti.cpp)
set_property(TARGET build-no-rtti PROPERTY CXX_STANDARD 11)
target_link_libraries(build-no-rtti lionss pthread)

add_executable(nightly src/nightly.cpp)
set_property(TARGET nightly PROPERTY CXX_STANDARD 11)
target_link_libraries(nightly lionss pthread)

add_executable(afl-fuzz src/afl-fuzz.cpp)
set_property(TARGET afl-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(afl-fuzz lionss pthread)

add_executable(maintainability-index src/maintainability-index.cpp)
set_property(TARGET maintainability-index PROPERTY CXX_STANDARD 11)
target_link_libraries(maintainability-index lionss pthread)

add_executable(leak-sanitizer src/leak-sanitizer.cpp)
set_property(TARGET leak-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(leak-sanitizer lionss pthread)

add_executable(android-arm64 src/android-arm64.cpp)
set_property(TARGET android-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-arm64 lionss pthread)

add_executable(concurrency-tests src/concurrency-tests.cpp)
set_property(TARGET concurrency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(concurrency-tests lionss pthread)

add_executable(zig-cc src/zig-cc.cpp)
set_property(TARGET zig-cc PROPERTY CXX_STANDARD 11)
target_link_libraries(zig-cc lionss pthread)

add_executable(gcc-trunk src/gcc-trunk.cpp)
set_property(TARGET gcc-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-trunk lionss pthread)

add_executable(jetson-build src/jetson-build.cpp)
set_property(TARGET jetson-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jetson-build lionss pthread)

add_executable(gcc-12 src/gcc-12.cpp)
set_property(TARGET gcc-12 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-12 lionss pthread)

add_executable(allocation-bench src/allocation-bench.cpp)
set_property(TARGET allocation-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(allocation-bench lionss pthread)

add_executable(config-matrix src/config-matrix.cpp)
set_property(TARGET config-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(config-matrix lionss pthread)

add_executable(tech-debt-report src/tech-debt-report.cpp)
set_property(TARGET tech-debt-report PROPERTY CXX_STANDARD 11)
target_link_libraries(tech-debt-report lionss pthread)

add_executable(startup-latency src/startup-latency.cpp)
set_property(TARGET startup-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(startup-latency lionss pthread)

add_executable(fixme-scan src/fixme-scan.cpp)
set_property(TARGET fixme-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(fixme-scan lionss pthread)

add_executable(coroutines-check src/coroutines-check.cpp)
set_property(TARGET coroutines-check PROPERTY CXX_STANDARD 11)
target_link_libraries(coroutines-check lionss pthread)

add_executable(cpplint src/cpplint.cpp)
set_property(TARGET cpplint PROPERTY CXX_STANDARD 11)
target_link_libraries(cpplint lionss pthread)

add_executable(valgrind-drd src/valgrind-drd.cpp)
set_property(TARGET valgrind-drd PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-drd lionss pthread)

add_executable(readme-render src/readme-render.cpp)
set_property(TARGET readme-render PROPERTY CXX_STANDARD 11)
target_link_libraries(readme-render lionss pthread)

add_executable(fuzz-regression src/fuzz-regression.cpp)
set_property(TARGET fuzz-regression PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-regression lionss pthread)

add_executable(oss-fuzz-sync src/oss-fuzz-sync.cpp)
set_property(TARGET oss-fuzz-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(oss-fuzz-sync lionss pthread)

add_executable(canary-build src/canary-build.cpp)
set_property(TARGET canary-build PROPERTY CXX_STANDARD 11)
target_link_libraries(canary-build lionss pthread)

add_executable(find-package-check src/find-package-check.cpp)
set_property(TARGET find-package-check PROPERTY CXX_STANDARD 11)
target_link_libraries(find-package-check lionss pthread)

add_executable(upload-artifacts src/upload-artifacts.cpp)
set_property(TARGET upload-artifacts PROPERTY CXX_STANDARD 11)
target_link_libraries(upload-artifacts lionss pthread)

add_executable(contract-tests src/contract-tests.cpp)
set_property(TARGET contract-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(contract-tests lionss pthread)

add_executable(dependency-pin src/dependency-pin.cpp)
set_property(TARGET dependency-pin PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-pin lionss pthread)

